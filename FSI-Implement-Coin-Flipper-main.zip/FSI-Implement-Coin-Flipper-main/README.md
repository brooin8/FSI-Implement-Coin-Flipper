# Code-Along 1.12.3 Penny Flip

Today your instructor will lead you through the process of creating a penny flipping game. If you haven't already done so, you can take a peek at the [finished product you'll be building](https://hackerusa-ce.github.io/code-along-1.12.3-penny-flip/) as well as [the bonus solution](https://hackerusa-ce.github.io/code-along-1.12.3-penny-flip/bonus.html).

### Attributions

Penny images come from [The Spruce Crafts](https://www.thesprucecrafts.com/describe-coins-to-collectors-768487). 